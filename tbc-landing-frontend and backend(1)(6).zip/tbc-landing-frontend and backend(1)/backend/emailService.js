import process from 'process';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import validator from 'validator'; // Import for email validation

dotenv.config();

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_USER,

    
pass: process.env.EMAIL_PASSWORD,
  },
});

async function sendEmail(to = 'anduamlakt77@gmail.com', subject, text) {
  try {
    // Enhanced email validation using validator.js
    if (!validator.isEmail(to)) {
      throw new Error('Invalid recipient email address');
    }

    console.log('Sending email to:', to); // Logging for tracking
    console.log('Email details:', { subject, text });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: to,
      subject: subject,
      text: text,
    });

    console.log('Email sent successfully!');
  } catch (error) {
    if (error.code === 'EAUTH') {
      console.error('Authentication error:', error.message);
      throw new Error('Invalid email credentials. Please check your settings.');
    } else if (error.code === 'ECONNREFUSED') {
      console.error('Connection error:', error.message);
      throw new Error('Failed to connect to email server. Please check your network.');
    } else {
      console.error('Unknown error sending email:', error.message);
      throw new Error('Failed to send email. Please try again later.');
    }
  }
}

export { sendEmail };