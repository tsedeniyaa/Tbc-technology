import express from 'express';
import { sendEmail } from './emailService.js';
import cors from 'cors';
import dotenv from 'dotenv'; // Load environment variables
import validator from 'validator'; 
import process from 'process';

dotenv.config(); // Load environment variables

const app = express();

app.use(express.json());
app.use(cors());

app.post('/Contact', async (req, res) => {
  try {
    const { name, company, recipientEmail, phone, message } = req.body; // Extract all fields

    console.log('Received request body:', req.body);

    // Validate recipient email (using a dedicated library for stricter validation)
    if (!validator.isEmail(recipientEmail)) {
      throw new Error('Invalid recipient email address');
  }

    await sendEmail(recipientEmail, `New Contact Form Submission from ${name} ${company} ${phone}}`, message);

    res.json({ success: true, message: 'Email sent successfully!' });
  } catch (error) {
    console.error('Error in Contact endpoint:', error);
    res.status(500).json({ success: false, message: 'Failed to send email' });
  }
});

// Use environment variable for port
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});