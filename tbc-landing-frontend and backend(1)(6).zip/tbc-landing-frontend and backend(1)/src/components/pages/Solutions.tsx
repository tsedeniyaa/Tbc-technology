import React, { useState } from "react";
import { services } from "../particles/SerivcePageInfo";

const Services: React.FC = () => {
  const [expandedServices, setExpandedServices] = useState<
    Record<string, boolean>
  >({});

  const handleToggleExpand = (serviceTitle: string) => {
    setExpandedServices((prevExpandedServices) => ({
      ...prevExpandedServices,
      [serviceTitle]: !prevExpandedServices[serviceTitle],
    }));
  };

  return (
    <section className="container mx-auto py-16 px-4 md:py-24 md:px-6 lg:py-32 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {" "}
          {/* Grid layout for cards */}
          {services.map((service) => (
            <article
              key={service.title}
              className={`bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 ${
                expandedServices[service.title] ? "expanded" : ""
              }`}
            >
              <div className="p-6 hover:shadow-xl">
                <h3 className="text-2xl font-semibold">{service.title}</h3>
                <div className="text-gray-700 prose break-words whitespace-pre-line text-justify">
                  {expandedServices[service.title]
                    ? service.description
                      ? service.description
                      : service.description
                    : service.description.slice(0, 140) + "..."}
                </div>
                <button
                  className="text-blue-500 hover:text-blue-700 font-medium rounded-lg px-3 py-1 mt-4"
                  onClick={() => handleToggleExpand(service.title)}
                >
                  {expandedServices[service.title] ? "Show Less" : "View More"}
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
