const About = () => (
  <div className="about-container grid grid-cols-1 md:grid-cols-2 gap-8 px-4 py-32 mx-auto">
    {/* Centered cards on larger screens */}
    <div className="col-span-2 md:col-span-1">
      <div className="mission bg-gray-100 rounded-xl shadow-md p-6 text-gray-700">
        <h2 className="text-2xl font-bold mb-4">Mission</h2>
        <p className="text-lg leading-loose">
          Our mission is to empower today's businesses to thrive in the digital
          world by providing innovative software solutions and services tailored
          to your unique needs.
        </p>
      </div>
    </div>
    <div className="col-span-2 md:col-span-1">
      <div className="vission bg-gray-100 rounded-xl shadow-md p-6 text-gray-700">
        <h2 className="text-2xl font-bold mb-4">vission</h2>
        <p className="text-lg leading-loose">
          At TBC, our vision is to be at the forefront of technological
          innovation, shaping the future with software solutions that simplify
          complexity, enhance lives, and transform industries. We aspire to
          empower businesses and individuals by harnessing the power of
          cutting-edge technology, making it accessible, adaptable, and
          sustainable.
        </p>
      </div>
    </div>
  </div>
);

export default About;
