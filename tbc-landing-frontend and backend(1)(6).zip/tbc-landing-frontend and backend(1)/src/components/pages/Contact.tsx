import React, { useState} from 'react';
import axios from 'axios';

const Contact: React.FC = () => {
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [Phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false); 

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => { 
    event.preventDefault();
    const payload = { 
      "name": name, 
      "company": company, 
      "recipientEmail": recipientEmail, 
      "Phone": Phone, 
      "message": message 
    }
    console.log(payload);
    setIsSubmitting(true); 

    try {
      //const formData = new FormData(event.target);
      const response = await axios.post('http://localhost:3000/Contact', payload);
     const responseData = await response.data;
      if (responseData.success) {
      alert('Email sent successfully!');
    } else {
        alert('Failed to send email');
      }
    } catch (error) {
     console.error('Error sending email:', error);
      alert('An error occurred while sending the email');
    } finally {
      setIsSubmitting(false); // Hide spinner after completion
    }
  };
  return (
  <div className="sm:px-6 md:px-8 py-12">
    {/* Add responsive padding for larger screens */}

    <div className="contact-container grid grid-cols-1 md:grid-cols-2 gap-32 px-4 py-16 mx-auto">
      {/* Left side: Company address */}
      <div className="flex flex-col justify-center items-start">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p className="text-gray-700 leading-relaxed">
          We'd love to hear from you! Please fill out the form below or visit
          our office.
        </p>
        <div className="address-box mt-8">
          <h3 className="font-semibold mb-2">Company Address</h3>
          <p className="text-gray-700 leading-loose">
            Give us a call Send as an email Our Location In Ethiopia <br />
            Phone: +251979060679 ,In America Merryland +13016553123 <br />
            Email: Info@TBC.com
          </p>
        </div>
      </div>

      {/* Right side: Contact form */}
    <form method='post' onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="flex flex-col">
          <label htmlFor="name" className="text-gray-700 font-semibold mb-2">
            Name
          </label>
          <input type="text" id="name" name="name" placeholder="Name" onChange={(e) => setName(e.target.value)}  required className="rounded-md border px-3 py-2 shadow-sm focus:ring-1 focus:ring-blue-500 focus:outline-none"/>
        </div>
        <div className="flex flex-col">
          <label htmlFor="company" className="text-gray-700 font-semibold mb-2">
            Your Company
          </label>
          <input
  type="text"
  id="company"
  placeholder="company"
  onChange={(e) => setCompany(e.target.value)} 
  className="rounded-md border px-3 py-2 shadow-sm focus:ring-1 focus:ring-blue-500 focus:outline-none"
/>
        </div>
        <div className="flex flex-col">
          <label htmlFor="recipientEmail" className="text-gray-700 font-semibold mb-2">
            Recipient Email (required)
          </label>
          <input
            type="email"
            id="recipientEmail"
            placeholder="recipientEmail"
            onChange={(e) => setRecipientEmail(e.target.value)} 
            className="rounded-md border px-3 py-2 shadow-sm focus:ring-1 focus:ring-blue-500 focus:outline-none"
          />
          
        </div>
        <div className="flex flex-col">
          <label htmlFor="phone" className="text-gray-700 font-semibold mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            placeholder="phone"
            onChange={(e) => setPhone(e.target.value)} 
            className="rounded-md border px-3 py-2 shadow-sm focus:ring-1 focus:ring-blue-500 focus:outline-none"
          />
        </div>
        <div className="flex flex-col">
          <label htmlFor="message" className="text-gray-700 font-semibold mb-2">
            Message
          </label>
          <textarea
            id="message"
            name="message"
            placeholder="message"
            onChange={(e) => setMessage(e.target.value)} 
            className="rounded-md border px-3 py-2 shadow-sm focus:ring-1 focus:ring-blue-500 focus:outline-none resize-none h-24"
          ></textarea>
          <div className="mt-4 flex items-center">
            <input
              type="checkbox"
              id="consent"
              name="consent"
              
              className="rounded-full border-2 mx-2"
            />
            <label htmlFor="consent" className="ml-2 text-sm text-gray-500">
              I agree that my personal data will be processed in accordance with
              the tbc technology solutions privacy policy for the purpose of
              providing me with appropriate information. (required).
            </label>
          </div>
        </div>
        <button
        type="submit"
        className="inline-flex items-center px-4 py-2 rounded-md bg-blue-500 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        {isSubmitting ? 'Sending...' : 'Send Message'}
        {isSubmitting && <div className="ml-2 spinner-border spinner-border-sm" role="status" aria-hidden="true"></div>}
      </button>
      </form>
    </div>
  </div>
  )
}

export default Contact;
