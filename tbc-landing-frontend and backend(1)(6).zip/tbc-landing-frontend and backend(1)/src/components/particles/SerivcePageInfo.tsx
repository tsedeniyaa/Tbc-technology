export const services = [
  {
    title: "Software Development",
    description:
      "We offer end-to-end process of conceptualizing, designing, building, testing, and maintaining custom software applications and solutions tailored to specific business or individual needs. Our dedicated team of experts at TBC collaborates closely with clients to understand their objectives and challenges, translating these into high-quality, scalable software that enhances efficiency, solves problems, and drives innovation.",
  },
  {
    title: "Technology Consultancy",
    description:
      "At TBC, we specialize in providing technical consultancy services to a diverse clientele, encompassing both local and international organizations. Our expertise is concentrated in three core areas: data collection and analysis, process automation, and standard operating procedure (SOP) designs. With a wealth of experience across these service categories, we deliver a comprehensive and holistic approach to data collection, visualization, and contextual modeling. Additionally, we offer innovative process automation and digitization models to empower organizations seeking to scale and streamline their business operations or monitor key performance indicators (KPIs). Furthermore, we assist our clients in defining and implementing standard operating procedures to guide their day-to-day operations, enhancing their automation and operational efficiency.",
  },
  {
    title: "Mobile Application Development",
    description:
      "TBC delivers future-focused custom mobile app development solutions. Backed by mobile app developers, our mobile app company strives to cater to businesses’ simple and complex challenges through innovative mobile applications.We cover end-to-end mobile application solutions from initial mobile application consulting to final delivery, maintenance, & deployment in the app store. As one of the best mobile app development companies in Ethiopia, we provide 360-degree solutions to our global clients.",
  },
  {
    title: "ERP system",
    description:
      "Enhance Business Operations with Comprehensive Enterprise resource planning (ERP) Software in Ethiopia Streamlining Data. Integrated and implementing ERP software is the key to unlocking your team’s full potential. Whether for management or finance, purchasing or sales, service or cost accounting, production or warehousing.",
  },
  {
    title: "Data Engineering",
    description:
      "At TBC, our Data Engineering services are second to none. We cover the entire spectrum, transforming raw data into robust pipelines, crafting tools for seamless data access, ensuring data quality, integrating diverse data sources, and helping you harness invaluable insights.",
  },
  {
    title: "Managing Services",
    description:
      "We offer Managed Services that serve as your strategic partner in efficiently managing essential aspects of your IT landscape, including network, applications, infrastructure, and security. Our comprehensive suite of services encompasses both on-demand and continuous support, ensuring the reliability and security of your systems. With our active administration services, we proactively address your priorities and challenges, allowing you to focus on your core business while we handle the intricacies of IT management.",
  },
  {
    title: "Digital Experience",
    description:
      "We harness the collective expertise of our strategists, designers, and developers to guide you through the entire journey, from concept to realization. We specialize in crafting digital products, services, and experiences that prioritize the end-user at every digital touchpoint. With a user-centric approach, we ensure that your digital presence not only meets your goals but also resonates with and engages your audience, creating a seamless and impactful digital experience.",
  },
  {
    title: "Outsourcing",
    description:
      "TBC offers developer hours, offshore dedicated developer capacity, and organization IT department outsourcing services to all corporations through our well-experienced team in the sector of operation. We also outsource IT departments of large corporations to manage day-to-day support requests of the organization and manage maintenance runs based on a given operation plan communicated on service engagement.",
    icon: "fas fa-paint-brush",
  },
  {
    title: "Trainings",
    description:
      "At TBC, our training services are crafted with precision to empower your team with the skills and knowledge essential for success in the dynamic landscape of outsourcing. These program can be for individuals or companies. Our training programs go beyond the conventional, offering a customized approach that aligns seamlessly with your organizational goals and industry requirements.",
  },
  {
    title: "Our Clients",
    description:
      "Here are the latest updates on our products, services, real-world use cases and events to offer valuable information and fresh insights. Our specific clients and the tasks we did are listed below.Engida Travel Technology - Bus Ticketing, PHPTRAVELS Website and Application",
  },
  {
    title: "Contact us",
    description:
      "Give us a call Send as an email Our Location In Ethiopia Info@TBC.com +251979060679 In America Merryland +13016553123",
  },
  // ... more services
];
